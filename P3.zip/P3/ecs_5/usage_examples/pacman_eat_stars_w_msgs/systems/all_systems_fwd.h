// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once

class CollisionsSystem;
class GameCtrlSystem;
class PacManSystem;
class RenderSystem;
class StarsSystem;

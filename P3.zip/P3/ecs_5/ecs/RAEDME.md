# Entity-Component-System v5

It is like ecs_4 but uses template meta-programming to compute identifiers


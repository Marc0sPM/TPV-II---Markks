// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once

void simplejson_demo();


